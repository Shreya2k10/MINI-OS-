


struct list_node_t
{
    struct list_node_t * next;
};


struct cond_t
{
    struct list_node_t queue;
};
