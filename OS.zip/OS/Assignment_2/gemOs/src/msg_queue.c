#include <msg_queue.h>
#include <context.h>
#include <memory.h>
#include <file.h>
#include <lib.h>
#include <entry.h>


/************************************************************************************/
/***************************Do Not Modify below Functions****************************/
/************************************************************************************/

struct msg_queue_info *alloc_msg_queue_info()
{
	struct msg_queue_info *info;
	info = (struct msg_queue_info *)os_page_alloc(OS_DS_REG);
	
	if(!info){
		return NULL;
	}
	return info;
}

void free_msg_queue_info(struct msg_queue_info *q)
{
	os_page_free(OS_DS_REG, q);
}

struct message *alloc_buffer()
{
	struct message *buff;
	buff = (struct message *)os_page_alloc(OS_DS_REG);
	if(!buff)
		return NULL;
	return buff;	
}

void free_msg_queue_buffer(struct message *b)
{
	os_page_free(OS_DS_REG, b);
}

/**********************************************************************************/
/**********************************************************************************/
/**********************************************************************************/
/**********************************************************************************/


int do_create_msg_queue(struct exec_context *ctx)
{
	int i;
	for(i=3; i<MAX_OPEN_FILES; i++)
	{
		if((ctx->files)[i]==NULL)
			break;
	}
	if(i==MAX_OPEN_FILES)
		return -ENOMEM;

	((ctx->files)[i])=alloc_file();
	((ctx->files)[i])->fops=NULL;
	struct msg_queue_info *msg_queue_ptr=alloc_msg_queue_info();
	msg_queue_ptr->head=0;
	msg_queue_ptr->tail=0;
	msg_queue_ptr->msg_buffer=alloc_buffer();
	for(int j=0; j<MAX_MSG; j++)
	{
		for(int k=0; k<MAX_MEMBERS; k++)
		{
			(msg_queue_ptr->brd_trgt)[j][k]=-1;
		}
	}
	for(int j=0; j<MAX_MEMBERS; j++)
	{
		(msg_queue_ptr->msg_count)[j]=0;
	}
	for(int j=0; j<MAX_MEMBERS; j++)
	{
		for(int k=0; k<MAX_MEMBERS; k++)
			(msg_queue_ptr->block)[j][k]=0;
	}

	struct msg_queue_member_info *info=msg_queue_ptr->info;
	(info->member_pid)[0]=ctx->pid;
	(info->member_count)=1;
	for(int j=1; j<MAX_MEMBERS; j++)
	{
		(info->member_pid)[j]=-1;
	}	

	((ctx->files)[i])->msg_queue=msg_queue_ptr;

	return i;
	
	/** 
	 * TODO Implement functionality to
	 * create a message queue
	 **/
}


int do_msg_queue_rcv(struct exec_context *ctx, struct file *filep, struct message *msg)
{
	/** 
	 * TODO Implement functionality to
	 * recieve a message
	 **/
	int temp, tail, head, i, j, del=0;
	struct message *msg_buf;
	if((filep==NULL) || (filep->msg_queue)==NULL)
		return -EINVAL;
	else
	{
		msg_buf=(filep->msg_queue)->msg_buffer;
		tail=(filep->msg_queue)->tail;
		head=(filep->msg_queue)->head;
		while(tail<head)
		{
			if(((msg_buf[tail]).to_pid==(ctx->pid)))
			{
				break;
			}
			else if(((msg_buf[tail]).to_pid)==BROADCAST_PID)
			{
				for(j=0; j<MAX_MEMBERS; j++)
				{
					if(((filep->msg_queue)->brd_trgt)[tail][j]==(ctx->pid))
					{
						((filep->msg_queue)->brd_trgt)[tail][j]=-1;
						del=1;
						break;
					}
				}
				if(j<MAX_MEMBERS)
					break;
			}
			tail++;
		}
		if(tail==head)
		{
			return 0;
		}
		else
		{
			(msg->from_pid)=(msg_buf[tail]).from_pid;
			(msg->to_pid)=(msg_buf[tail]).to_pid;
			i=0;
			while(((msg_buf[tail]).msg_txt)[i]!='\0')
			{
				(msg->msg_txt)[i]=((msg_buf[tail]).msg_txt)[i];
				i++;
			}
			(msg->msg_txt)[i]='\0';

			for(j=0; j<MAX_MEMBERS; j++)
			{
				if((((filep->msg_queue)->info)->member_pid)[j] == (ctx->pid))
				{
					((filep->msg_queue)->msg_count)[j]--;
					break;
				}
			}

			if(((msg_buf[tail]).to_pid)==BROADCAST_PID)
			{
				for(j=0; j<MAX_MEMBERS;j++)
				{
					if(((filep->msg_queue)->brd_trgt)[tail][j]!=-1)
					{
						del=0;
						break;
					}
				}
			}

			if((del) || (((msg_buf[tail]).to_pid)==(ctx->pid)))
			{		
				temp=tail+1;
				while(temp<head)
				{
					(msg_buf[tail]).from_pid=(msg_buf[temp]).from_pid;
					(msg_buf[tail]).to_pid=(msg_buf[temp]).to_pid;
					i=0;
					while(((msg_buf[temp]).msg_txt)[i]!='\0')
					{
						((msg_buf[tail]).msg_txt)[i]=((msg_buf[temp]).msg_txt)[i];
						i++;
					}
					((msg_buf[tail]).msg_txt)[i]='\0';

					for(int j=0; j<MAX_MEMBERS; j++)
					{
						((filep->msg_queue)->brd_trgt)[tail][j]=((filep->msg_queue)->brd_trgt)[temp][j];
					}
					temp++;
					tail++;
				}
				((filep->msg_queue)->head)--;
			}
			return 1;
		}
	}
}


int do_msg_queue_send(struct exec_context *ctx, struct file *filep, struct message *msg)
{
	/** 
	 * TODO Implement functionality to
	 * send a message
	 **/
	struct msg_queue_member_info *curr_q_info;
	int head, i, j, num=0, k, from_id;

	if((filep==NULL) || (filep->msg_queue)==NULL)
		return -EINVAL;
	else
	{
		curr_q_info=(filep->msg_queue)->info;
		head=(filep->msg_queue)->head;

		for( j=0; j<MAX_MEMBERS; j++)
		{
			if(((curr_q_info->member_pid)[j])==(ctx->pid))
			{
				from_id=j;
				break;
			}
		}
		if(j==MAX_MEMBERS)
			return -EINVAL;

		if((msg->to_pid)==BROADCAST_PID)
		{
			for( j=0; j<MAX_MEMBERS; j++ )
			{
				if((((curr_q_info->member_pid)[j]) != -1) && (j!=from_id) && ((!((filep->msg_queue)->block)[j][from_id])))
				{
					((filep->msg_queue)->brd_trgt)[head][j]=(curr_q_info->member_pid)[j];
					(((filep->msg_queue)->msg_count)[j])++;
					num++;
				}
			}
		}
		else
		{
			for(i=0; i<MAX_MEMBERS; i++)
			{
				if((curr_q_info->member_pid)[i]==(msg->to_pid))
				{
					if(!((filep->msg_queue)->block)[i][from_id])
					{
						(((filep->msg_queue)->msg_count)[i])++;
						num=1;
						break;
					}
					else
					{
						return -EINVAL;
					}
				}
			}
			if(i==MAX_MEMBERS)
				return -EINVAL;
		}
		if(num>0)
		{
			((filep->msg_queue)->msg_buffer)[head].from_pid=(ctx->pid);
			((filep->msg_queue)->msg_buffer)[head].to_pid=(msg->to_pid);
			k=0;
			while((msg->msg_txt)[k]!='\0')
			{
				(((filep->msg_queue)->msg_buffer)[head].msg_txt)[k]=(msg->msg_txt)[k];
				k++;
			}
			(((filep->msg_queue)->msg_buffer)[head].msg_txt)[k]=(msg->msg_txt)[k];

			((filep->msg_queue)->head)++;

		}
		return num;

	}
}

void do_add_child_to_msg_queue(struct exec_context *child_ctx)
{
	struct msg_queue_info *curr_msg_q;
	struct msg_queue_member_info *curr_q_info;
	for(int i=0; i<MAX_OPEN_FILES; i++)
	{
		if((child_ctx->files)[i]!=NULL)
		{
			curr_msg_q=((child_ctx->files)[i])->msg_queue;
			if(curr_msg_q !=NULL)
			{

				curr_q_info=curr_msg_q->info;
				for(int j=0; j<MAX_MEMBERS; j++)
				{
					if((curr_q_info->member_pid)[j]==-1)
					{
						(curr_q_info->member_pid)[j]=(child_ctx->pid);
						(curr_q_info->member_count)++;
						break;
					}
				}


			}
		}
	}
	/** 
	 * TODO Implementation of fork handler 
	 **/
}

void do_msg_queue_cleanup(struct exec_context *ctx)
{
	for(int i=0; i<MAX_OPEN_FILES; i++)
	{
		if(((ctx->files)[i]!=NULL) && (((ctx->files)[i])->msg_queue !=NULL))
		{
			do_msg_queue_close(ctx, i);
		}
	}
	return;
	/** 
	 * TODO Implementation of exit handler 
	 **/
}

int do_msg_queue_get_member_info(struct exec_context *ctx, struct file *filep, struct msg_queue_member_info *info)
{
	/** 
	 * TODO Implementation of exit handler 
	 **/
	if(filep->msg_queue!=NULL)
	{
		(info->member_count)=((filep->msg_queue)->info)->member_count;
		for(int i=0; i<MAX_MEMBERS; i++)
		{
			(info->member_pid)[i]=(((filep->msg_queue)->info)->member_pid)[i];
		}

		return 0;
	}
	else
	{
		return -EINVAL;
	}
}


int do_get_msg_count(struct exec_context *ctx, struct file *filep)
{
	/** 
	 * TODO Implement functionality to
	 * return pending message count to calling process
	 **/
	if((filep==NULL) || (filep->msg_queue)==NULL)
		return -EINVAL;

	for(int i=0; i<MAX_MEMBERS; i++)
	{
		if((((filep->msg_queue)->info)->member_pid)[i]==(ctx->pid))
			return (((filep->msg_queue)->msg_count)[i]);
	}

	return -EINVAL;
}

int do_msg_queue_block(struct exec_context *ctx, struct file *filep, int pid)
{
	
	if((filep==NULL) || ((filep->msg_queue)==NULL))
		return -EINVAL;
	struct msg_queue_member_info *curr_q_info=((filep->msg_queue)->info);
	int i,j;
	for (i = 0; i < MAX_MEMBERS; ++i)
	{
		if(((curr_q_info->member_pid)[i])==(ctx->pid))
			break;
		/* code */
	}
	if(i==MAX_MEMBERS)
		return -EINVAL;
	for (j = 0; j < MAX_MEMBERS; ++j)
	{
		if(((curr_q_info->member_pid)[j])==pid)
			break;
		/* code */
	}
	if(j==MAX_MEMBERS)
		return -EINVAL;
	(((filep->msg_queue)->block)[i][j])=1;
	return 0;

	/** 
	 * TODO Implement functionality to
	 * block messages from another process 
	 **/
}

int do_msg_queue_close(struct exec_context *ctx, int fd)
{
	/** 
	 * TODO Implement functionality to
	 * remove the calling process from the message queue 
	 **/
	if((((ctx->files)[fd]==NULL)) || (((ctx->files)[fd])->msg_queue == NULL))
		return -EINVAL;
	struct msg_queue_info *curr_msg_q=((ctx->files)[fd])->msg_queue;
	struct msg_queue_member_info *curr_q_info= curr_msg_q->info;
	int i;
	for(i=0; i<MAX_MEMBERS; i++)
	{
		if(((curr_q_info->member_pid)[i])== (ctx->pid))
		{
			((curr_q_info->member_pid)[i])=-1;
			(curr_q_info->member_count)--;
			if((curr_q_info->member_count)>0)
			{
				for(int j=0; j<MAX_MEMBERS; j++)
				{
					(curr_msg_q->block[i][j])=0;
					(curr_msg_q->block[i][j])=0;
				}
				(curr_msg_q->msg_count)[i]=0;
			}
			else
			{
				free_msg_queue_buffer(curr_msg_q->msg_buffer);
				free_msg_queue_info(curr_msg_q);
			}

			return 0;

		}
	}
	return -EINVAL;
}
