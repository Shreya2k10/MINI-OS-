#include <stdio.h>
#include <stdlib.h>

int x;

int main (void)
{
   int y, *z = (int*)malloc(sizeof(int));

   printf("Code: %p\n", (void*)main);
   printf("Global: %p\n", &x);
   printf("Heap: %p\n", z);
   printf("Stack: %p %p\n", &y, &z);

   return 0;
}
