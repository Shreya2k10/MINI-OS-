#include<stdio.h>
int main()
{
	int a=0;
	printf("%d",rand()%2);
}