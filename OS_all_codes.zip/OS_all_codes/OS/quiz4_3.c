#include<stdio.h>
#include <semaphore.h>
int main()
{
	sem_wait(&s1); 
	if (count == x) 
		count--; 
	else 
		count++; 
	sem_post(&s1);

sem_wait(&s2);

if (count == x) 
	count -= 2;
else 
	count += 2;
sem_post(&s2); 
}