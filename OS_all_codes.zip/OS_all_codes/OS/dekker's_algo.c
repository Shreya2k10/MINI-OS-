main(){
   int thread_no = 1;
   startThreads();
}
Thread1(){
   do {
      // entry section
      // wait until threadno is 1
      while (threado == 2)
            ;
      // critical section
      // exit section
      // give access to the other thread
      threadno = 2;
      // remainder section
   } while (completed == false)
}
Thread2(){
   do {
      // entry section
      // wait until threadno is 2
      while (threadno == 1)
            ;
      // critical section
      // exit section
      // give access to the other thread
      threadno = 1;
      // remainder section
   } while (completed == false)
}

