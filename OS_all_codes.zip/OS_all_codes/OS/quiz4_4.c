#include<pthread.h>
#include<stdio.h>
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cv = PTHREAD_COND_INITIALIZER;
int x = 0;
int y = 0;

int main(){
y = 2; 
while (x == 0) {
pthread_mutex_lock(&lock); 
x = 1;
pthread_cond_signal(&cv); 
}
printf("%d",y);

pthread_mutex_unlock(&lock); 

pthread_mutex_lock(&lock);
 pthread_cond_wait(&cv, &lock);
 pthread_mutex_unlock(&lock);

printf("%d",y);


}
