#include <stdio.h>
#include <unistd.h>
int main (void)
{
	sleep(1);
	return 0;
}
