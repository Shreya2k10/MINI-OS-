#define _GNU_SOURCE
#include<setjmp.h>
#include<stdio.h>
#include<stdlib.h>
#include<sched.h>
#include<signal.h>
#include <sys/types.h>
#include <sys/wait.h>

#define CHILD_STACK 16384

jmp_buf env;

int g (void *arg)
	{
		printf("g\n");
		longjmp(env,2);
	}

int f (void *arg)
	{
		printf("f\n");
		longjmp(env,1);		
	}

int main (void)
	{
		int j=0;
		int i=setjmp(env);
		

		if (i == 0)
			{
				clone (f, CHILD_STACK+malloc(CHILD_STACK), SIGCHLD, NULL);
			}
			
		else
			{
			j=setjmp(env);
			if (j==0)
				{
				clone (g, CHILD_STACK+malloc(CHILD_STACK), SIGCHLD, NULL);
				}
			}

		wait (NULL);
		printf("i=%d\n", i);
		printf("j=%d\n", j);

		if ((i != 0) || (j != 0)) exit(0);

		return 0;
	}
