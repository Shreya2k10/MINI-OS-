#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int x = 0;
int main (void)
{
	if (fork() == 0) {
		x++;
		execv("prog1", NULL);
		printf("%d\n", x);
}
else {
	if (fork() == 0) {
		x++;
		sleep(10);
		execv("prog", NULL);
		printf("%d\n", x);
	}
	else {
		wait(NULL);
		printf("%d\n", x);
		wait(NULL);
		printf("%d\n", x);
		}
	}
	return 0;
}
