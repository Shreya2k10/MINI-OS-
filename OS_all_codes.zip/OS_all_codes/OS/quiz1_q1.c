#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
typedef struct {
	int x;
} global_t;
global_t *g;
int f (int n)
{
	if (n==1) return 1;
	if (fork() == 0) {
	g->x++;
	return n*f(n-1);
	}
else {
	wait(NULL);
	return g->x;
	}
}
int main(void)
{
int y;
g = (global_t*)malloc(sizeof(global_t));
g->x = 5;
printf("%d\n",g->x-2);
y = f(g->x-2);
printf("%d\n", y*g->x);
return 0;
}
