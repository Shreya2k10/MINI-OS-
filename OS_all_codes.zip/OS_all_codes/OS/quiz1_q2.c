#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int x = 0;
int main (void) {
	int fd[2];
	pipe(fd);
	if (fork() == 0) {
		x++;
		close(fd[1]);
		printf("%d\n", x);
		read(fd[0], &x, sizeof(int));
		close(fd[0]);
		printf("%d\n", x);
		x++;
	}
	else {
		x--;
		close(fd[0]);
		printf("%d\n", x);
		write(fd[1], &x, sizeof(int));
		close(fd[1]);
		wait(NULL);
		printf("%d\n", x);
	}
	x++;
	return 0;
}
