#include <stdio.h>
#include <stdlib.h>

int main (void)
{
	printf("Pirates of Silicon Valley is an interesting movie!\n");
	printf("My pid: %d\n", getpid());
	return 0;
}