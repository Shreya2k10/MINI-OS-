#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/wait.h>




int z = 0;
int main (void)
{
	if (fork() == 0) {
		// This is child
		z = 100; // we are modifying the value of global variable z, then the child have a private copy of z with value 100
        }
        else {
		wait(NULL);
                printf("value of z: %d\n", z); // parent z variable still has initial value 0, does not have child modification
	}
	return 0;
}
