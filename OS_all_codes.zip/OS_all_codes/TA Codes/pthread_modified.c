#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/time.h>

#define SIZE 1000000000

int *a, num_threads;
unsigned long long *private_sum;

struct param{
    int tid;
    unsigned long long *private;
};

void *solver (void *param)
{
	int i, id,j;
	struct param *pm = (struct param*)(param);
	id = pm->tid;
	unsigned long long *private_sum = pm->private;
	private_sum[id] = (id)*100;
	
}	

int main (int argc, char *argv[])
{
	int i, j;
        struct param * pm;
	pthread_t *threads;
	pthread_attr_t attr;
        struct timeval tp_start, tp_end;
        unsigned long long sum=0; 

	if (argc != 2) {
		printf ("Need number of threads.\n");
		exit(1);
	}
	num_threads = atoi(argv[1]);
	threads = (pthread_t*)malloc(num_threads*sizeof(pthread_t));
	private_sum = (unsigned long long*)malloc(num_threads*sizeof(unsigned long long));
        pm = (struct param*)malloc(num_threads*sizeof(struct param));
        for (i=0; i<num_threads; i++){
		pm[i].tid = i;
		pm[i].private = private_sum;
	}


	pthread_attr_init(&attr);

        gettimeofday(&tp_start, NULL);

	for (i=0; i<num_threads; i++) {
                /* pthread_create arguments: thread pointer,
                                             attribute pointer,
                                             function pointer,
                                             argument pointer to the function
                */
		pthread_create(&threads[i], &attr, solver, &pm[i]);
   	}
        	
	for (i=0; i<num_threads; i++) {
		pthread_join(threads[i], NULL);
		sum += 
		[i];
	}

	printf("SUM: %llu\n", sum);

        gettimeofday(&tp_end, NULL);
        printf("Total time: %ld microseconds\n", tp_end.tv_sec*1000000+tp_end.tv_usec - (tp_start.tv_sec*1000000+tp_start.tv_usec));

	return 0;
}
