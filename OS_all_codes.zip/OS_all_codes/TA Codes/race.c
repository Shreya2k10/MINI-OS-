#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <pthread.h>
#include <sys/time.h>
       #include <unistd.h>
       #include <sys/types.h>


int *p;
int n;

void* work (void *arg)
{
   printf("(%d) address pointed to by p: %p\n", getpid(), p);
   int i;
   int tid = *(int*)arg;
   printf("tid:%d\n",tid);
   if(tid == 0){
   *p = *p + 10;
   }
   if(tid == 1){
   *p = *p + 20;
   }
      printf("value at p:%d modified by tid:%d\n",*p,tid);  
   return NULL;
}

int main (int argc, char *argv[])
{
   struct timeval tp_start, tp_end;

   if (argc != 2) {
      fprintf(stderr, "usage: race <value>\n");
      exit(1);
   }
   n = atoi(argv[1]);
   p = (int*)malloc(sizeof(int));
   assert(p != NULL);
   printf("(%d) address pointed to by p: %p\n", getpid(), p);
   *p = 0;
   pthread_t p1, p2;
   int tid[2];

   gettimeofday(&tp_start, NULL);
   tid[0]=0;
   pthread_create(&p1, NULL, work, &tid[0]);
   tid[1]=1;
   pthread_create(&p2, NULL, work, &tid[1]);
   pthread_join(p1, NULL);
   pthread_join(p2, NULL);
   gettimeofday(&tp_end, NULL);
   
   printf("Final value : %d, Time: %ld microseconds\n", *p, tp_end.tv_sec*1000000+tp_end.tv_usec - (tp_start.tv_sec*1000000+tp_start.tv_usec));

   return 0;
}
