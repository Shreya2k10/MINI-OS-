#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/wait.h>




int z = 0;
int main (void)
{
        int* a = (int*)malloc(10*sizeof(int));
	memset(a,0,10*sizeof(int)); //sets the memory to 0
	if (fork() == 0) {
		// This is child
		a[0] = 100; // after fork, the modification to memory by child is not visible to parent, child gets a private copy of a[0]
        }
        else {
		wait(NULL);
                printf("value of a[0]: %d\n", a[0]); // parent does not see the updated value of a[0], 100 as parentcopy and child copy is different after child modifies the array
	}
	return 0;
}
